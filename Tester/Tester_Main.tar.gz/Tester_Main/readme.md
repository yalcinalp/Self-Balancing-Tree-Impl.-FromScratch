Put your ScapegoatTree.h and TreeMap.h files into your_code folder.
After that run which test you want and wait.
If there are differences in the outputs, your output will be moved into new folder where you can compare.
You can run both testers simultaneously
